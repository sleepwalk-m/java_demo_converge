package com.itheima.dao;

/**
 * @Author Vsunks.v
 * @Date 2020/3/16 20:31
 * @Description: ${Description}
 */
public interface StudentDao {
}
