package com.itheima.service;

import com.itheima.domain.Student;

import java.util.ArrayList;

/**
 * @Author Vsunks.v
 * @Date 2020/3/16 20:31
 * @Description: ${Description}
 */
public interface StudentService {
    void save(ArrayList<Student> students);
}
